import json

with open('data//saved_data//config.json') as file:
    config = json.load(file)
